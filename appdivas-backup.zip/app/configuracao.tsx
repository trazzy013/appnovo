import { useState } from 'react';
import { View, Text, Switch, StyleSheet, Pressable } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from './src/context/ThemeContext';
import { useAuth } from './src/context/AuthContext';

function Row({
  label, value, onChange, primary, text, border,
}: {
  label: string; value: boolean; onChange: (v: boolean) => void;
  primary: string; text: string; border: string;
}) {
  return (
    <View style={[styles.row, { borderBottomColor: border }]}>
      <Text style={[styles.label, { color: text }]}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ true: primary, false: '#ccc' }}
      />
    </View>
  );
}

export default function ConfiguracaoScreen() {
  const { theme, isDark, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [notificacoes, setNotificacoes] = useState(true);

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <Pressable style={[styles.account, { backgroundColor: theme.surface }]} onPress={() => router.push((user ? '/perfil' : '/login') as any)}>
        <View style={[styles.accountIcon, { backgroundColor: theme.bannerBg }]}><Ionicons name="person-outline" color={theme.primary} size={21} /></View>
        <View style={{ flex: 1 }}><Text style={[styles.accountTitle, { color: theme.text }]}>{user?.nome ?? 'Acesse sua conta'}</Text><Text style={[styles.accountSub, { color: theme.textMuted }]}>{user ? user.email : 'Salve seu perfil e preferências'}</Text></View>
        <Ionicons name="chevron-forward" color={theme.textMuted} size={20}/>
      </Pressable>
      <Row label="Notificações " value={notificacoes} onChange={setNotificacoes}
        primary={theme.primary} text={theme.text} border={theme.border} />
      <Row label="Modo escuro" value={isDark} onChange={toggleTheme}
        primary={theme.primary} text={theme.text} border={theme.border} />
      <Text style={[styles.versao, { color: theme.textMuted }]}>Divas · Versão 1.0.0</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  account: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 15, marginBottom: 18 },
  accountIcon: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  accountTitle: { fontWeight: '800', fontSize: 15 },
  accountSub: { fontSize: 12, marginTop: 3 },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 14, borderBottomWidth: 1,
  },
  label: { fontSize: 16 },
  botao: { marginTop: 30, padding: 14, borderRadius: 10, alignItems: 'center' },
  botaoTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  versao: { textAlign: 'center', marginTop: 20, fontSize: 12 },
});
