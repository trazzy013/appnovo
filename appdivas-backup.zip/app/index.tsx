import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { useTheme } from './src/context/ThemeContext';
import { useAuth } from './src/context/AuthContext';

export default function Home() {
  const { theme } = useTheme();
  const { user } = useAuth();
return (
  <ScrollView
    contentContainerStyle={[
      styles.container,
      { backgroundColor: theme.background }
    ]}
  >
    <View style={styles.welcomeRow}><View><Text style={[styles.greeting, { color: theme.textMuted }]}>{user ? 'Olá, ' + user.nome.split(' ')[0] : 'Bem-vinda à Divas'}</Text><Text style={[styles.title, { color: theme.text }]}>Sua rotina de beleza</Text></View><TouchableOpacity style={[styles.profileButton, { backgroundColor: theme.primary }]} onPress={() => router.push((user ? '/perfil' : '/login') as any)}><Text style={styles.profileButtonText}>{user ? user.nome.charAt(0).toUpperCase() : '↗'}</Text></TouchableOpacity></View>

    <View
      style={[
        styles.banner,
        {
          backgroundColor: theme.bannerBg,
          borderLeftColor: theme.primary
        }
      ]}
    >
      <Text
        style={[
          styles.bannerText,
          { color: theme.textMuted }
        ]}
      >
       Produtos e cuidados escolhidos para valorizar a sua pele, todos os dias.
      </Text>
    </View>

    {/* Quiz da Pele */}
<TouchableOpacity
  style={[
    styles.quizBanner,
    {
      backgroundColor: theme.bannerBg,
      borderColor: theme.primary,
    },
  ]}
  onPress={() => router.push('/quiz')}
>
      
      <Text style={[styles.quizTitle, { color: theme.primary }]}>
        Descubra sua rotina ideal ✨
      </Text>

      <Text
        style={[
          styles.quizDescription,
          { color: theme.textMuted }
        ]}
      >
        Responda algumas perguntas rápidas e receba recomendações
        personalizadas para sua pele.
      </Text>

      <Text style={[styles.quizButton, { color: theme.primary }]}>
        Fazer Quiz →
      </Text>
    </TouchableOpacity>

    {/* Mais Vendidos */}
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: theme.primary }]}>
        Mais amados
      </Text>

      <View style={styles.productCard}>
        <Text style={styles.productName}>🧴 Shampoo Nutritivo</Text>
        <Text style={styles.productPrice}>R$ 49,90</Text>
      </View>
      <TouchableOpacity
      style={[
        styles.productCard]}
      onPress={() => router.push('/shampoo')}
    >
      <Text style={styles.productPrice}>
         Ver Produto
      </Text>
    </TouchableOpacity>

      <View style={styles.productCard}>
        <Text style={styles.productName}>💧 Hidratante Facial</Text>
        <Text style={styles.productPrice}>R$ 39,90</Text>
      </View>
      <TouchableOpacity
      style={[
        styles.productCard ]}
      onPress={() => router.push('/skincare')}
    >
      <Text style={styles.productPrice}>
         Ver Produto
      </Text>
    </TouchableOpacity>



      <View style={styles.productCard}>
        <Text style={styles.productName}>✨ Batom Matte Rosa</Text>
        <Text style={styles.productPrice}>R$ 29,90</Text>
      </View>
      <TouchableOpacity
      style={[styles.productCard]}
      onPress={() => router.push('/battom')}
    >
      <Text style={styles.productPrice}>
         Ver Produto
      </Text>
    </TouchableOpacity>

    </View>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: theme.primary }
      ]}
      onPress={() => router.push('/promocoes')}
    >
      <Text style={styles.promoButtonText}>
        Ver promoções
      </Text>
    </TouchableOpacity>
      <Text style={[styles.title, { color: theme.primary }]}>
        Explore por categoria
      </Text>
    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: theme.primary }
      ]}
      onPress={() => router.push('/produtos')}
    >
      <Text style={styles.promoButtonText}>
        Ver todos os produtos
      </Text>
    </TouchableOpacity>

  </ScrollView>

);
}




const styles = StyleSheet.create({
  container: { flexGrow: 1, alignItems: 'center', paddingVertical: 24, paddingHorizontal: 20 },
  welcomeRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  greeting: { fontSize: 14, fontWeight: '600' },
  profileButton: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  profileButtonText: { color: '#fff', fontWeight: '800', fontSize: 18 },
  banner: { borderLeftWidth: 4, borderRadius: 10, padding: 18, marginBottom: 20, width: '100%' },
  bannerText: { fontSize: 15, lineHeight: 24, fontStyle: 'italic' },
  promoButton: {
    paddingVertical: 14, paddingHorizontal: 40, borderRadius: 30,
    marginBottom: 30, width: '100%', alignItems: 'center', elevation: 5,
  },
  promoButtonText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
  title: { fontSize: 25, fontWeight: '800' },
  quizBanner: {
  width: '100%',
  borderWidth: 2,
  borderRadius: 15,
  padding: 20,
  marginBottom: 25,
  alignItems: 'center',
},

quizTitle: {
  fontSize: 18,
  fontWeight: 'bold',
  marginBottom: 8,
  textAlign: 'center',
},

quizDescription: {
  textAlign: 'center',
  lineHeight: 22,
  marginBottom: 10,
},

quizButton: {
  fontWeight: 'bold',
  fontSize: 16,
},

section: {
  width: '100%',
  marginBottom: 25,
},

sectionTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  marginBottom: 15,
},

productCard: {
  backgroundColor: '#532536',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

productName: {
  color: '#fff',
  fontSize: 16,
  fontWeight: 'bold',
},

productPrice: {
  color: '#ff5b9a',
  marginTop: 5,
  fontSize: 15,
},

testimonialCard: {
  backgroundColor: '#2a1520',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

stars: {
  fontSize: 16,
  marginBottom: 8,
},

comment: {
  color: '#fff',
  marginBottom: 8,
  lineHeight: 22,
},

author: {
  color: '#ffb6cf',
  fontWeight: 'bold',
},

benefit: {
  color: '#fff',
  fontSize: 15,
  marginBottom: 10,
},
});
