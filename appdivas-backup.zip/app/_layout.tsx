import { Stack, router } from 'expo-router';
import { useState } from 'react';
import {
  TouchableOpacity, View, Text, StyleSheet,
  Modal, Pressable, SafeAreaView, StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ThemeProvider, useTheme } from './src/context/ThemeContext';
import { AuthProvider, useAuth } from './src/context/AuthContext';

const menuItems = [
  { label: 'Início', href: '/' },
  { label: 'Diagnóstico de pele', href: '/quiz' },
  { label: 'Produtos', href: '/produtos' },
  { label: 'Meu perfil', href: '/perfil' },
  { label: 'Configurações', href: '/configuracao' },
];

function MenuButton({ onPress }: { onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ paddingLeft: 0 }}>
      <Ionicons name="menu" size={26} color="#ffffff" />
    </TouchableOpacity>
  );
}

function LayoutInner() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { theme, isDark } = useTheme();
  const { user } = useAuth();

  const navigate = (href: string) => {
    setMenuOpen(false);
    setTimeout(() => router.push(href as any), 300);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.background }}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: theme.headerBg },
          headerTintColor: '#fff',
          headerTitleAlign: 'center',
          contentStyle: { backgroundColor: theme.background },
        }}
      >
        <Stack.Screen
          name="index"
          options={{
            title: "Divas",
            headerLeft: () => <MenuButton onPress={() => setMenuOpen(true)} />,
          }}
        />
        <Stack.Screen name="login" options={{ title: '', headerShown: false }} />
        <Stack.Screen name="cadastro" options={{ title: '', headerShown: false }} />
        <Stack.Screen name="perfil" options={{ title: 'Meu perfil' }} />
        <Stack.Screen name="skincare" options={{ title: 'Skin Care' }} />
        <Stack.Screen name="shampoo" options={{ title: 'Shampoo' }} />
        <Stack.Screen name="carrinho" options={{ title: 'Carrinho' }} />
        <Stack.Screen name="battom" options={{ title: 'Battom' }} />
        <Stack.Screen name="promocoes" options={{ title: 'Promoções' }} />
        <Stack.Screen name="sobre" options={{ title: 'Sobre' }} />
        <Stack.Screen name="configuracao" options={{ title: 'Configuração' }} />
        <Stack.Screen name="produtos" options={{ title: 'Produtos' }} />
        <Stack.Screen name="quiz" options={{ title: 'Quiz' }} />
        <Stack.Screen name="pele" options={{ title: 'Pele' }} />
        <Stack.Screen name="rosto" options={{ title: 'Rosto' }} />
        <Stack.Screen name="cabelo" options={{ title: 'Cabelo' }} />
        <Stack.Screen name="categorias/Maquiagem/maquiagem" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem1" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem2" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem3" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem4" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem5" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem6" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem7" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Maquiagem/maquiagem8" options={{ title: 'Categoria de Maquiagem' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo1" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo2" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo3" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo4" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo5" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo6" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo7" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Cabelo/cabelo8" options={{ title: 'Categoria de Cabelo' }}/>
        <Stack.Screen name="categorias/Pele/pele" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele1" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele2" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele3" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele4" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele5" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele6" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele7" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Pele/pele8" options={{ title: 'Categoria de Pele' }}/>
        <Stack.Screen name="categorias/Rosto/rosto" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto1" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto2" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto3" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto4" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto5" options={{ title: 'Categoria de Rosto' }}/>
        <Stack.Screen name="categorias/Rosto/rosto6" options={{ title: 'Categoria de Rosto' }}/>
      </Stack>

      <Modal
        visible={menuOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setMenuOpen(false)}
      >
        <View style={styles.modalContainer}>
          <Pressable style={styles.overlay} onPress={() => setMenuOpen(false)} />
          <View style={[styles.drawer, { backgroundColor: theme.surface }]}>
            <View style={[styles.drawerHeader, { backgroundColor: theme.headerBg }]}>
              <View><Text style={styles.drawerTitle}>Olá{user ? `, ${user.nome.split(' ')[0]}` : ''}!</Text><Text style={styles.drawerSubtitle}>{user ? 'Seu espaço de beleza' : 'Entre para personalizar sua rotina'}</Text></View>
              <TouchableOpacity onPress={() => setMenuOpen(false)}>
                <Ionicons name="close" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            {menuItems.map((item) => (
              <TouchableOpacity
                key={item.href}
                style={[styles.menuItem, { borderBottomColor: theme.border }]}
                onPress={() => navigate(item.href)}
              >
                <Text style={[styles.menuItemText, { color: theme.text }]}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

export default function Layout() {
  return (
    <ThemeProvider><AuthProvider><LayoutInner /></AuthProvider></ThemeProvider>
  );
}

const styles = StyleSheet.create({
  modalContainer: { flex: 1,},
  overlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.4)' },
  drawer: { width: 280, height: '100%' },
  drawerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  drawerTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  drawerSubtitle: { color: '#ffe7f0', fontSize: 12, marginTop: 3 },
  menuItem: { padding: 16, borderBottomWidth: 1 },
  menuItemText: { fontSize: 16 },
});
