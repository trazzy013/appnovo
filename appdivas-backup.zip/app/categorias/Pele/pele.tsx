import { Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { useTheme } from '../../src/context/ThemeContext';

export default function Produtos() {
  const { theme } = useTheme();
return (
  <ScrollView
    contentContainerStyle={[
      styles.container,
      { backgroundColor: theme.background }
    ]}
  >
    <Text style={[styles.title, { color: theme.primary }]}>
      Produtos
    </Text>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele1')}
    >
      <Text style={styles.promoButtonText}>
        Hidratante facial
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele2')}
    >
      <Text style={styles.promoButtonText}>
        Espuma de limpeza
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele3')}
    >
      <Text style={styles.promoButtonText}>
        Gel de limpeza
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele4')}
    >
      <Text style={styles.promoButtonText}>
        Sabonete de limpeza
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele5')}
    >
      <Text style={styles.promoButtonText}>
        Protetor Corporal
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele6')}
    >
      <Text style={styles.promoButtonText}>
        Kit principia
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele7')}
    >
      <Text style={styles.promoButtonText}>
        Kit hidratante e reparador 
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./pele8')}
    >
      <Text style={styles.promoButtonText}>
        Protetor facial
      </Text>
    </TouchableOpacity>
  </ScrollView>

);
}




const styles = StyleSheet.create({
  container: { flexGrow: 1, alignItems: 'center', paddingVertical: 30, paddingHorizontal: 20 },
  banner: { borderLeftWidth: 4, borderRadius: 10, padding: 18, marginBottom: 20, width: '100%' },
  bannerText: { fontSize: 15, lineHeight: 24, fontStyle: 'italic' },
  promoButton: {
    paddingVertical: 14, paddingHorizontal: 40, borderRadius: 30,
    marginBottom: 30, width: '100%', alignItems: 'center', elevation: 5,
  },
  promoButtonText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
  title: { fontSize: 28, marginBottom: 20, fontWeight: 'bold' },
  quizBanner: {
  width: '100%',
  borderWidth: 2,
  borderRadius: 15,
  padding: 20,
  marginBottom: 25,
  alignItems: 'center',
},


section: {
  width: '100%',
  marginBottom: 25,
},

sectionTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  marginBottom: 15,
},

productCard: {
  backgroundColor: '#2a1520',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

productName: {
  color: '#fff',
  fontSize: 16,
  fontWeight: 'bold',
},

productPrice: {
  color: '#ff438b',
  marginTop: 5,
  fontSize: 15,
},

testimonialCard: {
  backgroundColor: '#2a1520',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

stars: {
  fontSize: 16,
  marginBottom: 8,
},

comment: {
  color: '#fff',
  marginBottom: 8,
  lineHeight: 22,
},

author: {
  color: '#ffb6cf',
  fontWeight: 'bold',
},

benefit: {
  color: '#fff',
  fontSize: 15,
  marginBottom: 10,
},
});
