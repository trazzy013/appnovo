import { Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { useTheme } from '../../src/context/ThemeContext';

export default function Produtos() {
  const { theme } = useTheme();
return (
  <ScrollView
    contentContainerStyle={[
      styles.container,
      { backgroundColor: theme.background }
    ]}
  >
    <Text style={[styles.title, { color: theme.primary }]}>
      Produtos
    </Text>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto1')}
    >
      <Text style={styles.promoButtonText}>
        Creme hidratante
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto2')}
    >
      <Text style={styles.promoButtonText}>
        Kit skicare
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto3')}
    >
      <Text style={styles.promoButtonText}>
        Serum facial Rn
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto4')}
    >
      <Text style={styles.promoButtonText}>
        Serum facial Am
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto5')}
    >
      <Text style={styles.promoButtonText}>
        Gel de limpeza
      </Text>
    </TouchableOpacity>

    <TouchableOpacity
      style={[
        styles.promoButton,
        { backgroundColor: '#ff4f9a' }
      ]}
      onPress={() => router.push('./rosto6')}
    >
      <Text style={styles.promoButtonText}>
        Serum facial Nc
      </Text>
    </TouchableOpacity>
  </ScrollView>

);
}




const styles = StyleSheet.create({
  container: { flexGrow: 1, alignItems: 'center', paddingVertical: 30, paddingHorizontal: 20 },
  banner: { borderLeftWidth: 4, borderRadius: 10, padding: 18, marginBottom: 20, width: '100%' },
  bannerText: { fontSize: 15, lineHeight: 24, fontStyle: 'italic' },
  promoButton: {
    paddingVertical: 14, paddingHorizontal: 40, borderRadius: 30,
    marginBottom: 30, width: '100%', alignItems: 'center', elevation: 5,
  },
  promoButtonText: { color: '#fafafa', fontSize: 17, fontWeight: 'bold' },
  title: { fontSize: 28, marginBottom: 20, fontWeight: 'bold' },
  quizBanner: {
  width: '100%',
  borderWidth: 2,
  borderRadius: 15,
  padding: 20,
  marginBottom: 25,
  alignItems: 'center',
},


section: {
  width: '100%',
  marginBottom: 25,
},

sectionTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  marginBottom: 15,
},

productCard: {
  backgroundColor: '#2a1520',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

productName: {
  color: '#fff',
  fontSize: 16,
  fontWeight: 'bold',
},

productPrice: {
  color: '#ff005d',
  marginTop: 5,
  fontSize: 15,
},

testimonialCard: {
  backgroundColor: '#2a1520',
  padding: 15,
  borderRadius: 12,
  marginBottom: 10,
},

stars: {
  fontSize: 16,
  marginBottom: 8,
},

comment: {
  color: '#fff',
  marginBottom: 8,
  lineHeight: 22,
},

author: {
  color: '#ffb6cf',
  fontWeight: 'bold',
},

benefit: {
  color: '#fff',
  fontSize: 15,
  marginBottom: 10,
},
});
