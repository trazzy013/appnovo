import { useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from './src/context/AuthContext';

export default function Login() {
  const { signIn, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const submit = async () => {
    if (!email.trim() || !senha) return Alert.alert('Preencha seus dados', 'Informe seu e-mail e sua senha para continuar.');
    try {
      await signIn(email.trim().toLowerCase(), senha);
      router.replace('/');
    } catch (error) {
      Alert.alert('Não foi possível entrar', error instanceof Error ? error.message : 'Tente novamente.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.hero}><Text style={styles.logo}>D</Text><Text style={styles.brand}>divas</Text><Text style={styles.tagline}>Sua beleza, do seu jeito.</Text></View>
      <View style={styles.card}>
        <Text style={styles.title}>Que bom ter você aqui</Text><Text style={styles.subtitle}>Entre para cuidar da sua pele com mais segurança.</Text>
        <Text style={styles.label}>E-mail</Text>
        <TextInput style={styles.input} placeholder="voce@email.com" placeholderTextColor="#A8939C" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail} />
        <Text style={styles.label}>Senha</Text>
        <View style={styles.password}><TextInput style={styles.passwordInput} placeholder="Sua senha" placeholderTextColor="#A8939C" secureTextEntry={!showPassword} value={senha} onChangeText={setSenha} /><Pressable onPress={() => setShowPassword(!showPassword)}><Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={21} color="#8B6876" /></Pressable></View>
        <Pressable style={[styles.button, isLoading && styles.buttonDisabled]} onPress={submit} disabled={isLoading}>{isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Entrar</Text>}</Pressable>
        <Pressable onPress={() => router.push('/cadastro' as any)}><Text style={styles.link}>Ainda não tem conta? <Text style={styles.linkBold}>Criar conta</Text></Text></Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({ screen: { flex: 1, justifyContent: 'center', backgroundColor: '#FFF2F6', padding: 24 }, hero: { alignItems: 'center', marginBottom: 30 }, logo: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#B51E5B', color: '#fff', textAlign: 'center', lineHeight: 60, fontSize: 34, fontWeight: '800' }, brand: { color: '#48202F', fontSize: 30, fontWeight: '800', marginTop: 7 }, tagline: { color: '#896876', marginTop: 4 }, card: { backgroundColor: '#fff', borderRadius: 24, padding: 24, shadowColor: '#7C294B', shadowOpacity: .12, shadowRadius: 20, elevation: 4 }, title: { color: '#48202F', fontSize: 23, fontWeight: '800' }, subtitle: { color: '#896876', marginTop: 7, marginBottom: 24, lineHeight: 20 }, label: { color: '#5C3745', fontWeight: '700', marginBottom: 8 }, input: { height: 52, borderWidth: 1, borderColor: '#EAD8DE', borderRadius: 14, paddingHorizontal: 15, color: '#3B202B', marginBottom: 18, backgroundColor: '#FFFDFD' }, password: { height: 52, borderWidth: 1, borderColor: '#EAD8DE', borderRadius: 14, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFDFD', marginBottom: 24 }, passwordInput: { flex: 1, color: '#3B202B' }, button: { height: 54, borderRadius: 15, backgroundColor: '#B51E5B', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }, buttonDisabled: { opacity: .65 }, buttonText: { color: '#fff', fontWeight: '800', fontSize: 16 }, link: { textAlign: 'center', color: '#78505F' }, linkBold: { color: '#B51E5B', fontWeight: '800' } });
